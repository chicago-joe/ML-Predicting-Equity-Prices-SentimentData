from celery import Celery
from celery.schedules import crontab
import os

app = Celery('worker', broker=os.environ['BROKER'], backend='rpc://', include=['worker.tasks'])

# app.conf.update( CELERY_WORKER_SEND_TASK_EVENTS = True,
#                 CELERY_ACCEPT_CONTENT = ['pickle', 'json', 'msgpack', 'yaml'],
                # CELERY_SEND_EVENTS = True,
# CELERY_SEND_TASK_SENT_EVENT = True,
# CELERY_IGNORE_RESULT = True,
# CELERY_DEFAULT_EXCHANGE = 'default',
# CELERY_ACKS_LATE = True,
# CELERYD_PREFETCH_MULTIPLIER = 1,
# CELERY_CREATE_MISSING_QUEUES = True,)