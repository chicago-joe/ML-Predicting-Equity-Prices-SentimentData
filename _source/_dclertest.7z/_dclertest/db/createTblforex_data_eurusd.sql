DROP TABLE IF EXISTS forex_data_EURUSD;
SET timezone = 'UTC';
CREATE TABLE forex_data_EURUSD (date timestamp with time zone NOT NULL UNIQUE,  open FLOAT, high float, low float, close float, volume int, average float, nbars int);
